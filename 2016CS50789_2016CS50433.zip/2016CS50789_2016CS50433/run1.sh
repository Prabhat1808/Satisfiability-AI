#! /bin/bash

./generate_clauses $1".graph" $1".satinput" "aux.txt"
