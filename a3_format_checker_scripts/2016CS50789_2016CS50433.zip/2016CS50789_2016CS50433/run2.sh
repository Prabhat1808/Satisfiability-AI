#! /bin/bash

./generate_subgraphs $1".satoutput" "aux.txt" $1."subgraphs"
