#! /bin/bash

g++ ./my_sat.cpp -o ./generate_clauses
g++ ./subgraphs.cpp -o ./generate_subgraphs
